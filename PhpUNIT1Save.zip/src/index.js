import React from 'react';
import './index.css';
import { Link, Routes , Route } from 'react-router-dom';

export default function App() {
  return (
    <div className="App">
      <nav>
      <div className="nav-buttons">
        <Link to="/"><img src={Logo} alt="Accueil Logo" className="logo" /></Link>
        <Link to="/AjouterRecette"><img src={Logo2} alt="NewRecette" className="nav-button" /></Link>
      </div></nav>

      <Routes>
        <Route path="/"   element={<Accueil/>}/>
        <Route path="/AjouterRecette"  element={<AjouterRecette/>}/>
      </Routes>

    </div>
  );
}

<nav>
<img src="Pokeball.png" alt="Pokémon Logo" className="logo" />
<div className="nav-buttons">
  <img src="Pokedex.png" alt="Home" className="nav-button" />
  <img src="about.png" alt="About" className="nav-button" />
</div>
</nav>

